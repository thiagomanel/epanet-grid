#!/bin/bash

java -Djava.library.path=lib/linux -cp classes org.ourgrid.epanetgrid.JEpanetToolkitMain malha.inp saida.txt log.txt
